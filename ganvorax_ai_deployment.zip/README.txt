GANVORAX AI - Streamlit deployment files

Files:
- app.py: Streamlit application
- requirements.txt: Python dependencies

Run locally:
1. Install Python 3.10 or newer.
2. Run: pip install -r requirements.txt
3. Run: streamlit run app.py

Deploy:
1. Upload app.py and requirements.txt to a GitHub repository.
2. Open https://share.streamlit.io/ and sign in with GitHub.
3. Choose the repository, branch, and app.py as the main file.
4. Deploy.

Note: This version retains the six sample jobs in the original project. Replace the sample dataset with real job listings before presenting it as a live job portal.
